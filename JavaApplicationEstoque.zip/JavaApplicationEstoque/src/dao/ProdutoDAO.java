
package dao;

import beans.Produto;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ProdutoDAO {
    private Conexao conexao;
    private Connection conn;
    
    public ProdutoDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
    public void inserir(Produto produto){
        String sql = "INSERT INTO produto (descricao, qtde, preco) VALUES (?,?,?) ";
        
        try{
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, produto.getDescricao());
            stmt.setInt(2, produto.getQtde());
            stmt.setDouble(3,produto.getPreco());
            stmt.execute();
        }catch(Exception e){
            System.out.println("Erro ao inserir produto: "+ e.getMessage());
        }
    }
    
    public void alterar(Produto produto){
        String sql = "UPDATE produto SET descricao=?, qtde=?, preco=? WHERE id=?";
        try{
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, produto.getDescricao());
            stmt.setInt(2, produto.getQtde());
            stmt.setDouble(3,produto.getPreco());
            stmt.setInt(4,produto.getId());
            stmt.execute();
        }catch(Exception e){
            System.out.println("Erro ao atualizar produto: "+ e.getMessage());
        }
    }
    
    public void excluir(int id){
        String sql = "DELETE FROM produto WHERE id = ?";
        try{
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setInt(1,id);
            stmt.execute();
        }catch(Exception e){
            System.out.println("Erro ao excluir produto: "+ e.getMessage());
        }
    }
    
    public Produto getProduto(int id){
        String sql = "SELECT * FROM produto WHERE id =?";
        
        try{
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            Produto produto = new Produto();
            rs.next();
            produto.setId(rs.getInt("id"));
            produto.setDescricao(rs.getString("descricao"));
            produto.setQtde(rs.getInt("qtde"));
            produto.setPreco(rs.getDouble("preco"));
            return produto;
        
        }catch(Exception e){
            System.out.println("Erro ao atualizar produto: "+ e.getMessage());
            return null;
        }
        
    }
    public List<Produto> getProduto(){
        String sql = "SELECT * FROM produto";
        try{
          PreparedStatement stmt = this.conn.prepareStatement(sql);
          ResultSet rs = stmt.executeQuery();
          List<Produto> listaProduto = new ArrayList<>();
          while(rs.next()){
              Produto p = new Produto();
              p.setId(rs.getInt("id"));
              p.setDescricao(rs.getString("descricao"));
              p.setQtde(rs.getInt("qtde"));
              p.setPreco(rs.getDouble("preco"));
              listaProduto.add(p);
          }
          return listaProduto;
        }catch(Exception e){
            return null;
        }
    }
}
